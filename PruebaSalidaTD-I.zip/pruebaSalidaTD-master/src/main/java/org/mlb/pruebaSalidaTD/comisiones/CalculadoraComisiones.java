package org.mlb.pruebaSalidaTD.comisiones;

import java.util.List;

public interface CalculadoraComisiones {
	
	int calcula(List<Integer> listaVentas);
}
