Requerimientos a Desarrollar:<br>
El  jefe  de  proyectos,  quien  lleva  un  control  meticuloso  de  las  actividades  del  proyecto,  le  ha solicitado a Usted que realice las siguientes tareas:<br>
1.Realizar consultas a la base de datos <br>
2.Construir un algoritmo de cálculo de comisiones de venta<br>
3.Construir una unidad de pruebas para verificar los algoritmos de cálculo de comisiones de venta<br>
4.Crear un Monitor de Gestión de Vendedores<br>
5.Crear una API REST que disponibilice la información del monitor de gestión de vendedores<br>
![DiagramaBBDD](https://github.com/mlilloblanco/pruebaSalidaTD/blob/master/DiagramaBBDD.png)


